
let mensaje: string = 'Hola';
let numero: number = 123;
let booleano: boolean = true;
let fecha: Date = new Date(); 

let cualqueircosa: string | number | Date | boolean;

cualqueircosa = 123;
cualqueircosa = 'hola';
cualqueircosa = true;
cualqueircosa = fecha;

 let heroe = {
    nombre: 'X', 
    poder: 'Volar',
 }

   heroe = {
    nombre: 'X',
    poder: 'Volar'
   }





